<?php
/**
 * php assets 代理
 *
 * @author xianyu.hrh@tmall.com
 */
ob_start();

set_error_handler('error_handler');
set_exception_handler('exception_handler');

$config = parseConfig();

$MIMES = array(
    'js'  => 'application/javascript',
    'css' => 'text/css',
    'gif' => 'image/gif',
    'txt' => 'text/plain',
    'png' => 'image/png',
    'jpg' => 'image/jpeg',
    'jpeg'=> 'image/jpeg',
    'swf' => 'application/x-shockwave-flash',
    'xml' => 'text/xml',
    'ico' => 'image/x-icon',
    'md'  => 'text/html',
    'html'=> 'text/html',
    'htm' => 'text/html',
    'htc' => 'text/x-component' //htc文件不能跨域，实在是没有意义
);

/* 发送头信息 */
if(array_key_exists(FILE_TYPE, $MIMES)){
    header('Content-Type: ' . $MIMES[FILE_TYPE]);
}
header('Cache-Control: max-age=0');

//发送跨域头，css、js就不发送了。解决对iconfont的代理工作
if(!IS_CSS_JS){
    header('Access-Control-Allow-Origin: *');
}

if(COMBO){
    if(!IS_CSS_JS){
        sendMsg('illegal combo, please check');
    }
    $files = explode(FILE_SPLIT, REQUEST_URI);
}else{
    $files = array(REQUEST_URI);
}

//识别git目录关系
$gitPathPrefix = $config['gitPathPrefix'];
if(!is_array($gitPathPrefix)){
    $gitPathPrefix = array('src', 'build');
}

foreach($files as $file){
    $file = BASE_PATH . $file;
    $isGit = IS_G_HOST || '/g/' === strtolower(substr($file, 0, 3));

    //全代理的前提下
    if(PROXY){
        requestFile($file, BIND_IP, BIND_HOST);
        continue;
    }

    //开始查找本地代理目录
    $dest = BASE_ROOT . $file;

    //当前路径下是否存在
    if(false !== outputFile($dest)){
        continue;
    }

    //GIT目录下的替换，含基于git的发布
    if($isGit){
        $gitDest = preg_replace('/\/\d+(\.\d+){2}\//', '/{git}/', $dest);

        //基本GIT的覆盖式发布（无版本号，只有目录）
        //g.tbcdn.cn/tm/buy/init.js
        //g.tbcdn.cn/tm/buy/core/init.js
        //a.tbcdn.cn/g/tm/buy/core/init.js
        if(false === strpos($gitDest, '{git}')){
            //在仓库名称后面加上{git}，方便替换
            $gitDest = preg_replace('/(\/g\/\w+\/)(\w+)\b/', '$1$2/{git}', $gitDest);
        }

        //替换为第一个目录
        if(false !== outputFile(str_replace('{git}', $gitPathPrefix[0], $gitDest))){
            continue;
        }

        //替换为第二个目录
        if(false !== outputFile(str_replace('{git}', $gitPathPrefix[1], $gitDest))){
            continue;
        }
    }

    //本地不存在，去其他地方获取
    requestFile($file, BIND_IP, BIND_HOST);
}

/**
 * 文件编码转换
 */
function charset_convert($content, $from, $to){
    if(function_exists('iconv')){
        $content = iconv($from, $to, $content);
    }else if(function_exists('mb_convert_encoding')){
        $content = mb_convert_encoding($content, $to, $from);
    }

    return $content;
}

/**
 * 过滤文件内容，对文件进行处理
 */
//function filterContent($content){
    //编码转换，仅对本地文件有效
    //在文件第一行以以下格式指定编码
    // /* encoding=utf-8:gbk */
    // 第一项指定文件内容本身的编码，第二项指定期望输出的编码
    //$lines = preg_split('/[\n\r]+/', $content, 2);  //返回两项，则第一项为第一行，第二项为剩下所有
    //if(preg_match('/\bencoding=([\w-]+):([\w-]+\b)/', $lines[0], $matches)){
        //$content = charset_convert($content, strtoupper($matches[1]), strtoupper($matches[2]));
    //}

    //return $content;
//}

/**
 * 读取文件
 */
function outputFile($file){
    if(is_file($file)){
        $fp = fopen($file, 'r');

        if($fp){
            $content .= IS_CSS_JS ? '/* local file:' . $file . ' */ ' : '';
            $content .= fread($fp, filesize($file));
        }else{
            sendMsg('occur en error while reading file:' . $file);
        }
        fclose($fp);

        //获取配置中的编码信息，以决定是否要进行编码转换
        global $config;
        $charset = $config['charset'];
        if(is_array($charset) && IS_CSS_JS){
            foreach($charset as $key => $val){
                if(false !== strpos($file, $key)){
                    $to_content = charset_convert($content, $val[0], $val[1]);
                    $content = (false === $to_content) ? 'error occured while converting encoding, check your charset section in config.php' : $to_content;
                    break;
                }
            }
        }

        print $content;
        return true;
    }

    return false;
}

/**
 * 规范文件名，去处查询串
 */
function formatFileName($file = ''){
    if(!is_string($file)){
        return '';
    }

    $pos = strpos($file, '?');
    return false === $pos ? $file : substr($file, 0, $pos);
}

/**
 * 获取文件类型（后缀）
 * 简化处理，只处理纯粹的文件名
 */
function getFileType($file = ''){
    if(!is_string($file)){
        return '';
    }

    $pos = strrpos($file, '.');
    return false === $pos ? '' : strtolower(substr($file, $pos + 1));
}

/**
 * 通过curl获取指定的文件
 */
function requestFile($pathname, $ip, $host){
    if(IS_G_HOST){
        $pathname = '/g' . $pathname;
    }

    //如果是对g的请求，那么全部从日常获取
    //考虑到g的增量发布，从日常环境获取没有问题
    //对于g下的覆盖式发布，问题也不大，可以使用
    $isGit = false;

    if(0 === strpos($pathname, '/g/')){
        $isGit = true;
        $ip = DAILY_IP;
        $host = DAILY_HOST;
    }

    $result = fetchRemoteFile('http://' . $ip . $pathname, $host);

    //文件未找到
    if(404 === $result['http_code'] && $isGit){
        //目前git发布可能会出现日常失败，结果线上却发布成功了。这样日常上没有代码，线上却有
        //为此再进行一次请求
        $result = fetchRemoteFile('http://' . PUB_IP . $pathname, PUB_HOST);
    }

    $content = $result['content'];
    $http_code = $result['http_code'];

    if(404 === $http_code){
        send404($content);
    }

    print $content;
}

/**
 * 封装curl请求
 */
function fetchRemoteFile($url, $host){
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'HOST: ' . $host,
    ));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $content = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    $result = array(
        'content' => $content,
        'http_code' => $http_code
    );

    curl_close($ch);
    return $result;
}

/**
 * 发送错误信息
 */
function sendMsg($msg){
    header('content-type:text/plain;charset=utf-8');
    print $msg;
    exit;
}

function send404($msg){
    ob_end_clean();
    header('content-type:text/html');
    header('HTTP/1.1 404 Not Found');
    header('Status: 404 Not Found');
    print $msg;
    exit;
}

/**
 * 错误处理
 */
function error_handler($errno, $errstr, $errfile, $errline){
    switch($errno){
        case E_ERROR:
        case E_PARSE:
        case E_CORE_ERROR:
        case E_COMPILE_ERROR:
        case E_USER_ERROR:
            ob_end_clean();
            print('$errstr ' . $errfile . ' 第 $errline 行.');
            break;
        case E_STRICT:
        case E_USER_WARNING:
        case E_USER_NOTICE:
        default:
            break;
    }
}

function exception_handler($exception){
    print($exception->__toString());
}


/**
 * 获取配置信息
 */
function parseConfig(){
    //获取配置文件
    $file = 'config.php';

    if(!is_file($file)){
        sendMsg('missing ' . $file . ' file, please create');
    }

    $config = require $file;
    if(!is_array($config)){
        sendMsg('there is some wrong with you ' . $file . ', please check');
    }

    //解析绑定目录
    $bindRoot = $config['bindRoot'];
    $bindRoot = empty($bindRoot) ? '' : $bindRoot;
    $bindRoot = rtrim($bindRoot, '/');

    if(false === is_dir($bindRoot)){
        sendMsg('directory ' . $bindRoot . ' not exists, please check');
    }

    define('BIND_ROOT', $bindRoot);

    //解析配置环境信息
    $bindEnv = '';
    $proxy = false;

    $serverName = $_SERVER['HTTP_HOST'];
    $hostMap = $config['hostMap'];

    if(is_array($hostMap)){
        if(array_key_exists($serverName, $hostMap)){
            $bindHostMap = $hostMap[$serverName];

            $bindEnv = $bindHostMap['env'];
            $proxy = $bindHostMap['proxy'];
        }
    }

    //env配置为空的时候，自动根据域名判断当前要绑定到的环境
    if(!$bindEnv){
        if(preg_match('/\b(daily|demo)\b/', $serverName)){
            $bindEnv = 'daily';
        }else{
            $bindEnv = 'pub';
        }
    }

    //解析绑定环境信息
    $envMap = $config['envMap'];

    //获取日常的绑定信息作为备用
    $dailyEnv = array_merge(array(
        'ip' => '10.235.136.37',
        'host' => 'assets.daily.taobao.net'
    ), $envMap['daily']);

    define('DAILY_IP', $dailyEnv['ip']);
    define('DAILY_HOST', $dailyEnv['host']);

    //获取线上环境的绑定信息作为备用
    $pubEnv = array_merge(array(
        'ip' => '115.238.23.251',
        'host' => 'assets.taobaocdn.com'
    ), $envMap['pub']);

    define('PUB_IP', $pubEnv['ip']);
    define('PUB_HOST', $pubEnv['host']);

    //获取本次对应的绑定环境
    $env = array_key_exists($bindEnv, $envMap) ? $envMap[$bindEnv] : array();
    $ip = $env['ip'];
    $host = $env['host'];

    if(!$ip){
        $ip = ('daily' === $bindEnv) ? DAILY_IP : '115.238.23.251';
        $host = ('daily' === $bindEnv) ? DAILY_HOST : 'assets.taobaocdn.com';
    }

    define('BIND_IP'     , $ip);
    define('BIND_HOST'   , $host);
    define('PROXY'       , $proxy);
    define('COMBO_SPLIT' , '??');
    define('FILE_SPLIT'  , ',');

    //路径解析
    $url = $_SERVER['REQUEST_URI'];                 //请求路径
    $url = str_replace('http://' . $serverName, '', $url);    //在启用了代理等情况下，可能会造成uri获取不对，再进行一次替换

    $path = '';
    define('COMBO', false !== strpos($url, COMBO_SPLIT));   //是否是COMBO形式

    if(COMBO){
        list($path, $url) = explode(COMBO_SPLIT, $url);
        $url = formatFileName($url);
    }else{
        $url = formatFileName($url);
    }

    //路径定义
    define('REQUEST_URI', $url);
    define('BASE_PATH', $path);

    define('FILE_TYPE', getFileType($url));
    define('IS_CSS_JS', 'js' === FILE_TYPE || 'css' === FILE_TYPE);
    define('IS_G_HOST', 1 === preg_match('/^g\./', $serverName));
    define('BASE_ROOT', BIND_ROOT . (IS_G_HOST ? '/g' : ''));

    return $config;
}

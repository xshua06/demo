# PHP Assets 代理

## 要求

* php5.2+
* curl 模块
* iconv 或 mbstring 模块

## 配置

建议使用nginx，服务器的配置请参考：[https://github.com/moldauder/moldauder.github.com/issues/1](https://github.com/moldauder/moldauder.github.com/issues/1)

* 修改hosts文件，增加以下内容

```
127.0.0.1 a.tbcdn.cn l.tbcdn.cn g.tbcdn.cn
127.0.0.1 assets.daily.taobao.net g.assets.daily.taobao.net
```

至此，配置完成。

需要注意的是，完全可以将以上assets域名皆绑定到本地。然后再通过本地的combo配置来把请求配置到正确的环境下。另外，combo代理会输出`max-age=0`的缓存控制头信息，保证客户端不缓存响应内容。

特别的，当执行线上验证时，请务必去掉绑定。在真实的环境下测试。

## bindRoot目录结构

bindRoot下只需按照CDN规则建立需要代理的目录即可，如下：

```
---bindRoot
  ---apps
    ---tmallbuy (对应 http://svn.app.taobao.net/repos/tmallbuy/trunk/tmallbuy/assets)
  ---g (gitlab下仓库所在目录)
    ---tm
      ---buy-cart (对应 git@gitlab.alibaba-inc.com:tm/buy-cart.git)
    ---mui
      ---seed (对应 git@gitlab.alibaba-inc.com:mui/seed.git)
```

注意，如果svn仓库是在分支上进行开发的，那么检出所开发分支即可，在多个分支间切换开发可用`svn switch`命令。git下则为`git checkout`命令。

## 配置文件 config.php

### bindRoot

指定本地的代理目录。combo.php将从该目录查找文件。规则是：

0. 直接根据确定的路径查找文件是否存在
0. 如果是Git下的文件，则执行第3步
0. 如果是覆盖式的Git发布，则确定group、仓库库位置。对于非覆盖式的，则确定版本号位置
0. 根据配置项`gitPathPrefix`中指定的文件夹顺序，在指定的文件夹里查找文件是否存在
0. 本地查找失败时，转向远程服务器获取

特别的，对于Git下的文件，是在`bindRoot/g`目录下查找的。

### gitPathPrefix

指定Git发布下的文件夹查找顺序。根据Git仓库规则，需要存在`build`目录，同时我们建议把代码放在`src`目录下。该配置项即配置`src`、`build`的查找顺序。你也可以根据自己的需求增加新的目录

### envMap

环境配置，默认指定了`daily`、`prepub`、`pub`三个环境所对应的IP和HOST。你也可以根据需要增加新的环境配置，并在`hostMap`一节中使用

### hostMap

域名配置。指定将域名绑定到哪个环境，以及是否使用全代理。如：

```
    'g.assets.daily.taobao.net'=> array('env'=> 'daily', 'proxy'=> false),
```

其含义是：

* 将`g.assets.daily.taobao.net` 绑定到`daily`环境。`daily`环境的`IP`、`HOST`值由`envMap`中指定
* 不打开全代理（`proxy`项）。当打开全代理（值为true）时。请求将直接转到对应环境（`env`项指定的环境），不再执行本地查找

特别地，对于GIT下的文件，均从日常环境（`envMap`中的`daily`一节）中获取文件。

### charset

编码配置，通过此项配置目录、文件的编码。其格式为

```
'charset' => array(
    '/tm/' => array('utf-8', 'gbk')
)
```

即`key`指定目录或者文件。`val`部分指定编码信息，其中第一项为文件编码，第二项是输出编码。

## 用法

### 文件编码转换

此前在文件头部增加标记行的功能已经移除，采用在配置项中配置的方式进行，以便可以批量对某个目录进行配置，降低配置工作量。

此功能依赖`iconv`或者`mbstring`库。

### a.tbcdn.cn中combo了GIT仓库文件在预发环境下的访问问题

由于Git仓库没有对应的预发环境，将`a.tbcdn.cn`、`l.tbcdn.cn`绑定到预发环境时，会出现请求404的请求，比如下面的请求：

```
http://a.tbcdn.cn/??apps/tmall/header/chaoshi/header_v2.js,g/mui/minicart/1.0.3/minicart.js
```

对应地，`config.php`中的配置（`hostMap`下`a.tbcdn.cn`项）是：

```
    'a.tbcdn.cn' => array('env'=> 'prepub', 'proxy'=> true),
```

此时，即把请求转到预发环境，并且对于Git仓库的文件仍然走正常的本地查找，本地查找不到时去日常环境获取。这样，整个请求仍然是正常的

> 使用过程中，有任何问题或者建议请与仙羽联系
